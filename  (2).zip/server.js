// Use Express
var express = require("express");
// Use body-parser
var bodyParser = require("body-parser");
// Use MongoDB
var mongodb = require("mongodb");
var ObjectID = mongodb.ObjectID;
// The database variable
var database;
// The products collection
var PRODUCTS_COLLECTION = "products";


// Create new instance of the express server
var app = express();

// Define the JSON parser as a default way 
// to consume and produce data through the 
// exposed APIs
app.use(bodyParser.json());

// Create link to Angular build directory
// The `ng build` command will save the result
// under the `dist` folder.
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));

// Local database URI.
const LOCAL_DATABASE = "mongodb+srv://priyanka:priyanka123@cluster0.jz4sp.mongodb.net/tcsdb?retryWrites=true&w=majority"; //your uri
// Local port.
const LOCAL_PORT = 8080;

// Init the server
mongodb.MongoClient.connect(process.env.MONGODB_URI || LOCAL_DATABASE,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    }, function (error, client) {

        // Check if there are any problems with the connection to MongoDB database.
        if (error) {
            console.log(error);
            process.exit(1);
        }

        // Save database object from the callback for reuse.
        database = client.db();
        console.log("Database connection done.");

        // Initialize the app.
        var server = app.listen(process.env.PORT || LOCAL_PORT, function () {
            var port = server.address().port;
            console.log("App now running on port", port);
        });
    });

/*  "/api/status"
 *   GET: Get server status
 *   PS: it's just an example, not mandatory
 */
app.get("/api/status", function (req, res) {
    res.status(200).json({ status: "UP" });
});

/*  "/api/products"
 *  GET: finds all products
 */
app.get("/api/products", function (req, res) {
    database.collection(PRODUCTS_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

/*  "/api/products"
 *   POST: creates a new product
 */
app.post("/api/products", function (req, res) {
    var product = req.body;

    if (!product.name) {
        manageError(res, "Invalid product input", "Name is mandatory.", 400);
    } else if (!product.brand) {
        manageError(res, "Invalid product input", "Brand is mandatory.", 400);
    } else if (!product.price) {
        manageError(res, "Invalid product input", "Price is mandatory.", 400);
    }else if (!product.fashionimage) {
        manageError(res, "Invalid product input", "image is mandatory.", 400);
    }else {
        database.collection(PRODUCTS_COLLECTION).insertOne(product, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new product.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});

/*  "/api/products/:id"
 *   DELETE: deletes product by id
 */
app.delete("/api/products/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid product id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTION).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete product.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

// Errors handler.
function manageError(res, reason, message, code) {
    console.log("Error: " + reason);
    res.status(code || 500).json({ "error": message });
}

var PRODUCTS_ADMIN = "admin";

app.post('/api/admins',(req,res)=>{
    var admin=req.body;
    database.collection(PRODUCTS_ADMIN).insertOne(admin, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to create new Admin.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
})
app.get('/api/admins',(req,res)=>{
    database.collection(PRODUCTS_ADMIN).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get Admin.");
        } else {
            res.status(200).json(data);
        }
    });
})
app.get('/api/admins',(req,res)=>{
    database.collection(PRODUCTS_ADMIN).find({type: string}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get Admin");
        } else {
            res.status(200).json(data);
        }
    });
})


var PRODUCTS_USER = "user";

app.post('/api/users',(req,res)=>{
    var user=req.body;
    database.collection(PRODUCTS_USER).insertOne(user, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to create new user.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
})
app.get('/api/users',(req,res)=>{
    database.collection(PRODUCTS_USER).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get user.");
        } else {
            res.status(200).json(data);
        }
    });
})
app.delete("/api/users/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid user id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_USER).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete Customer.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});
var PRODUCTS_WISH = "wish";

app.post('/api/wishs',(req,res)=>{
    var wish=req.body;
    database.collection(PRODUCTS_WISH).insertOne(wish, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to create new Wish.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
})
app.get('/api/wishs',(req,res)=>{
    database.collection(PRODUCTS_WISH).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get Wishlist.");
        } else {
            res.status(200).json(data);
        }
    });
})
app.delete("/api/wishs/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid wishlist id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_WISH).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete Wish.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});
var PRODUCTS_SHOP = "shop";

app.post('/api/shops',(req,res)=>{
    var shop=req.body;
    database.collection(PRODUCTS_SHOP).insertOne(shop, function (err, doc) {
        if (err) {
            manageError(res, err.message, "Failed to create new shop.");
        } else {
            res.status(201).json(doc.ops[0]);
        }
    });
})
app.get('/api/shops',(req,res)=>{
    database.collection(PRODUCTS_SHOP).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
}) 
app.delete("/api/shops/:id", function (req, res) {
    if (req.params.id.length > 24 || req.params.id.length < 24) {
        manageError(res, "Invalid user id", "ID must be a single String of 12 bytes or a string of 24 hex characters.", 400);
    } else {
        database.collection(PRODUCTS_SHOP).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete Customer.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});