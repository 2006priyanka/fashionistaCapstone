import { Component, Input, OnInit, OnChanges, Output, EventEmitter } from '@angular/core';

import { ProductService } from 'src/app/entities/product/product.service';
import { IProduct } from 'src/app/entities/product/product.model';
import { IWish,Wish } from '../entities/wishlist/wish.model';
import { WishService } from '../entities/wishlist/wish.service';
import { ShopService } from '../entities/shopping/shop.service';
import { IShop, Shop } from '../entities/shopping/shop.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})


export class ProfileComponent implements OnInit {

  products: Array<IProduct> = [];
 
  @Input() productToDisplay: IProduct = null;
  selectedProduct: IProduct;


  //new
  @Output() createdWish = new EventEmitter<IWish>();
  @Output() createdShop = new EventEmitter<IShop>();
  constructor(protected productService: ProductService,protected wishService: WishService, protected shopService: ShopService) { }


  ngOnInit(): void {
    this.loadAll();
  }

   // Load all products.
   private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
        console.log(this.products);
      });
  }

 /*  onSubmit(index: number) {
    this.selectedProduct = this.products[index];
    this.productService.postToCart('testUser', this.selectedProduct)
      .then((result: any) => {
        console.log(result);
        console.log('succesfully sent to server!')
      });
      alert(this.selectedProduct.name)
  }  */
 onSubmit(index: number) {
  this.selectedProduct = this.products[index];
    const wish = new Wish(this.selectedProduct.name, this.selectedProduct.price,this.selectedProduct.fashionimage);
    this.wishService.create(wish).then((result: IWish) => {
    
        this.createdWish.emit(result);
      
    });
    alert(this.selectedProduct.name)
  }

onSub(index: number) {
  this.selectedProduct = this.products[index];
    const shop = new Shop(this.selectedProduct.name, this.selectedProduct.price,this.selectedProduct.fashionimage);
    this.shopService.create(shop).then((result: IShop) => {
    
        this.createdShop.emit(result);
      
    });
    alert(this.selectedProduct.name)
  }
}
