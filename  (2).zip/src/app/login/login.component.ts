
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Admin, IAdmin } from '../entities/admin/admin.model';
import { AdminService } from '../entities/admin/admin.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  type: string='';
  pass: string = '';
  error: boolean = false;

  admins: Array<IAdmin> = [];
  @Input() adminToDisplay: IAdmin = null;
  selectedAdmin: IAdmin;
  @Output() createdAdmin = new EventEmitter<IAdmin>();
 
  constructor(protected adminService: AdminService, protected formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.initForm()

  }

  onSubmit(){
    alert("You have succesfully Sign In")
    this.router.navigate(['product']);
  }
  hideError() {
    this.error = false;
  }


  private initForm() {
    this.loginForm = new FormGroup({
      type: new FormControl(this.type,[ Validators.required,Validators.pattern(/admin[0-9]+/)]),
      pass: new FormControl(this.pass, 
        [
          Validators.required, 
          Validators.pattern(/[a-zA-Z0-9]{8,12}/)
      ] 
       )
    });
  }  
}