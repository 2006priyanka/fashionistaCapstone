import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { IShop, Shop } from './shop.model';


@Injectable({
    providedIn: 'root'
})
export class ShopService {
    private shopsUrl = '/api/shops';

    constructor(private http: Http) { }

    get(): Promise<Array<IShop>> {
        return this.http.get(this.shopsUrl)
            .toPromise()
            .then(response => response.json())
            .catch(this.error);
    }

    create(shop: Shop): Promise<IShop> {
        return this.http.post(this.shopsUrl, shop)
            .toPromise()
            .then(response => response.json())
            .catch(this.error);
    }
    delete(id: string): Promise<any> {
        return this.http.delete(`${this.shopsUrl}/${id}`)
            .toPromise()
            .then(response => response.json())
            .catch(this.error);
    }

    private error(error: any) {
        let message = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(message);
    }
}
