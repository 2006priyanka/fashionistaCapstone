
import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { IUser } from '../entities/users/users.model';
import { UserService } from '../entities/users/users.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit,OnChanges {

  users: Array<IUser> = [];
  @Input() userToDisplay: IUser = null;

  constructor(protected userService: UserService) { }

  ngOnInit(): void {
    this.loadAll();
  }

  ngOnChanges(): void {
    if (this.userToDisplay !== null) {
      this.users.push(this.userToDisplay);
    }
  }

  delete(id: string) {
    this.userService.delete(id).then((result: any) => this.loadAll());
    alert(id)
  }

  private loadAll() {
    this.userService
      .get()
      .then((result: Array<IUser>) => {
        this.users = result;
      });
  }
   
}

